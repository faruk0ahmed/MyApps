package com.example.customwebviewapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class WebsiteAdapter(
    private val websites: List<Website>,
    private val onClick: (Website) -> Unit
) : RecyclerView.Adapter<WebsiteAdapter.WebsiteViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WebsiteViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_website, parent, false)
        return WebsiteViewHolder(view)
    }

    override fun onBindViewHolder(holder: WebsiteViewHolder, position: Int) {
        val website = websites[position]
        holder.bind(website)
    }

    override fun getItemCount() = websites.size

    inner class WebsiteViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val nameText: TextView = itemView.findViewById(R.id.websiteName)

        fun bind(website: Website) {
            nameText.text = website.name
            itemView.setOnClickListener { onClick(website) }
        }
    }
}