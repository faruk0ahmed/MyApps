package com.example.customwebviewapp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.AdView

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adView: AdView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        MobileAds.initialize(this) {}

        adView = findViewById(R.id.adView)
        val adRequest = AdRequest.Builder().build()
        adView.loadAd(adRequest)

        val websites = listOf(
            Website("MovieBox", "https://moviebox.ng/"),
            Website("Filmzie", "https://filmzie.com/home"),
            Website("Plex TV", "https://www.plex.tv/"),
            Website("Goldmines", "https://www.youtube.com/@GoldminesTelefilms"),
            Website("Movie Sentral", "https://www.youtube.com/@MovieCentral/videos")
        )

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = WebsiteAdapter(websites) { website ->
            val intent = Intent(this, WebViewActivity::class.java)
            intent.putExtra("url", website.url)
            startActivity(intent)
        }
    }
}