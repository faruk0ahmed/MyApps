package com.example.customwebviewapp

data class Website(val name: String, val url: String)